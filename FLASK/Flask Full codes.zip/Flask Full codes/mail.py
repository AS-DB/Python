from flask import Flask
from flask_mail import Mail, Message

app=Flask(__name__)
mail=Mail(app)

app.config['MAIL_SERVER']='smtp.gamil.com'
app.config['MAIL_PORT']=465
app.config['MAIL_USERNAME']='abc@gamil.com'
app.config['MAIL_PASSWORD']='123'
app.config['MAIL_USE_TLC']=False
app.config['MAIL_USE_SSL']=True
mail=Mail(app)

@app.route("/")
def index():
    msg=Message("hello",sender='xyz@gmail.com', recipients=['abc@gmail.com'])
    msg.body="hello flask!"
    mail.send(msg)
    return "message sent"

if __name__=='__main__':
    app.run(debug=True)